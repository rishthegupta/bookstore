package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.bean.Book;
import com.capgemini.bookstore.bean.Customer;
import com.capgemini.bookstore.dao.BookstoreBook;
import com.capgemini.bookstore.dao.BookstoreCustomer;

@Service
public class BookstoreServiceImpl implements BookstoreService {
	
	
	@Autowired
	private BookstoreCustomer customerDAO;
	@Autowired
	private BookstoreBook bookDAO;

	
	//Customer Services Implementation
	@Override
	public Customer addCustomer(Customer customer) {
		if(customer!=null)
		{
			customerDAO.save(customer);
			return customer;
		}
		return null;
	}

	@Override
	public Customer editCustomer(Customer customer) {
		if(customer!=null)
		{
			customerDAO.save(customer);
			return customer;
		}
		return null;
	}

	@Override
	public Customer removeCustomer(int customerID) {
		
		Customer customer=customerDAO.getOne(customerID);
		customerDAO.delete(customer);
		
		return customer;
	}

	@Override
	public Customer findCustomer(int customerID) {
		// TODO Auto-generated method stub
		return customerDAO.getOne(customerID);
	}

	@Override
	public List<Customer> findAllCustomer() {
		return customerDAO.findAll();
	}
	
	
	
	//Books Services Implementation
	
	@Override
	public Book addBook(Book book) {
		if(book!= null)
		{
			bookDAO.save(book);
			return book;
		}
		return null;
	}

	@Override
	public Book removeBook(int bookID) {
		
		if(bookID>0)
		{
			bookDAO.delete(bookDAO.getOne(bookID));
			return bookDAO.getOne(bookID);
		}
		
		return null;
	}

	@Override
	public List<Book> fetchAllBooks() {
		
		return bookDAO.findAll();
	}

}
