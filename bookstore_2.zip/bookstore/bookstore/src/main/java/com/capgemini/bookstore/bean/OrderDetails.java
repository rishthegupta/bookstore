package com.capgemini.bookstore.bean;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "orderdetail")
public class OrderDetails {
	
	@Id
	
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int orderDetailId;
	@ManyToOne
	@JoinColumn(name="ord_Id")
	
	private Order orderId;
	@OneToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="book_ID")
	private Book bookId;
	private int subtotal;
	private int orderQuantity;
	public OrderDetails(int orderDetailId, Order orderId, Book bookId, int subtotal, int orderQuantity) {
		super();
		this.orderDetailId = orderDetailId;
		this.orderId = orderId;
		this.bookId = bookId;
		this.subtotal = subtotal;
		this.orderQuantity = orderQuantity;
	}
	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getOrderDetailId() {
		return orderDetailId;
	}
	public void setOrderDetailId(int orderDetailId) {
		this.orderDetailId = orderDetailId;
	}
	public Order getOrderId() {
		return orderId;
	}
	public void setOrderId(Order orderId) {
		this.orderId = orderId;
	}
	public Book getBookId() {
		return bookId;
	}
	public void setBookId(Book bookId) {
		this.bookId = bookId;
	}
	public int getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(int subtotal) {
		this.subtotal = subtotal;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	@Override
	public String toString() {
		return "OrderDetails [orderDetailId=" + orderDetailId + ", orderId=" + orderId + ", bookId=" + bookId
				+ ", subtotal=" + subtotal + ", orderQuantity=" + orderQuantity + "]";
	}
	
	
	

}
