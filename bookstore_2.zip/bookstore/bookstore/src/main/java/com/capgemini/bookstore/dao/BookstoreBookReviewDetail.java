package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.bean.BookReviewDetail;

public interface BookstoreBookReviewDetail extends JpaRepository<BookReviewDetail, Integer> {

}
