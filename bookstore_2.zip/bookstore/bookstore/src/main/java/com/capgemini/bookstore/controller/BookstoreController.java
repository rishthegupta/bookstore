package com.capgemini.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.bean.Book;
import com.capgemini.bookstore.bean.Customer;
import com.capgemini.bookstore.service.BookstoreServiceImpl;

@RestController
public class BookstoreController {
	
	
	@Autowired
	private BookstoreServiceImpl bookstoreService;
	
	@GetMapping(value="/")
	public String homePage()
	{
		return "BookStore HomePage";
	}
	
	//Controllers for Customer 
	//Fetch All Customers
	@GetMapping(value="/bookstore/fetchAllCustomer")
	public ResponseEntity<List<Customer>> fetchAllCustomer()
	{
		return ResponseEntity.accepted().body(bookstoreService.findAllCustomer());
	}
	
	//Fetch one customer, with customer id
	@GetMapping(value="/bookstore/fetchOneCustomer/{customerID}")
	public ResponseEntity<Customer> fetchOneCustomer(@PathVariable int customerID)
	{
		
		Customer customer=bookstoreService.findCustomer(customerID);
		return ResponseEntity.accepted().body(customer);
	}
	
	//Add new customer
	
	@PostMapping(value="/bookstore/addCustomer")
	public ResponseEntity<Customer> addCustomer(@ModelAttribute Customer customer)
	{
		return ResponseEntity.accepted().body(bookstoreService.addCustomer(customer));
	}
	
	
	//Remove Customer
	
	@DeleteMapping(value="/bookstore/removeCustomer/{customerID}")
	public ResponseEntity<Customer> removeCustomer(@PathVariable int customerID)
	{
		return ResponseEntity.accepted().body(bookstoreService.removeCustomer(customerID));
	}
	
	//Edit Customer
	
	@PostMapping(value="/bookstore/editCustomer")
	public ResponseEntity<Customer> editCustomer(@RequestBody Customer customer)
	{
		return ResponseEntity.accepted().body(bookstoreService.editCustomer(customer));
	}
	
	
	
	
	//Controllers for Book
	//Add Book
	@PostMapping(value="/bookstore/addBook")
	public ResponseEntity<Book> addBook(@ModelAttribute Book book)
	{
		return ResponseEntity.accepted().body(bookstoreService.addBook(book));
	}
	
	//Delete Book
	@DeleteMapping(value="bookstore/removeBook/{bookID}")
	public ResponseEntity<Book> removeBook(@PathVariable int bookID)
	{
		return ResponseEntity.accepted().body(bookstoreService.removeBook(bookID));
	}
	
	//Remove Book
	@DeleteMapping(value="bookstore/")
	public ResponseEntity<List<Book>> fetchAllBook()
	{
		return ResponseEntity.accepted().body(bookstoreService.fetchAllBooks());
	}
	
	
	

}
