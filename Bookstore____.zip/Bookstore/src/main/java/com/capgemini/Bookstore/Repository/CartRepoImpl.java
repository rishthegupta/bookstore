package com.capgemini.Bookstore.Repository;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Cart;
@Repository
public class CartRepoImpl implements CartRepo {

	@Override
	public Cart removeCart() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cart addBookToCart() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Cart updateQuantity() {
		// TODO Auto-generated method stub
		return null;
	}

}
