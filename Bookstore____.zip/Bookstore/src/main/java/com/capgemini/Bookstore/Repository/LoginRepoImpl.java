package com.capgemini.Bookstore.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Customer;

@Repository
@Transactional
public class LoginRepoImpl implements LoginRepo {

	@PersistenceContext
	EntityManager entitymanager;
	
	@Override
	public boolean addAdmin(Admin admin) {
		// TODO Auto-generated method stub
		System.out.println("hello2:::"+admin);
		entitymanager.persist(admin);
		return true;
	}

	@Override
	public boolean addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		entitymanager.persist(customer);
		return true;
	}

	@Override
	public boolean loginAdmin(String adminEmailId, String password) {
		System.out.println("adm"+adminEmailId);
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("Select password from Admin adm where adm.adminEmailId=:adminEmailId");
		query.setParameter("adminEmailId", adminEmailId);
		System.out.println("hello \n");
		String pass=(String) query.getSingleResult();
		System.out.println("your password :"+pass);
		if(pass.equals(password))
				return true;
		return false;
	}

	@Override
	public boolean loginCustomer(String customerEmail, String password) {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("Select password from Customer adm where adm.customerEmail=:customerEmail");
		query.setParameter("customerEmail", customerEmail);
	//	System.out.println("hello \n");
		String pass=(String) query.getSingleResult();
		System.out.println("your password :"+pass);
		if(pass.equals(password))
				return true;
		return false;
	}

}
