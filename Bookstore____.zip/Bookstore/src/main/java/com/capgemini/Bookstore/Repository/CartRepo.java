package com.capgemini.Bookstore.Repository;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Cart;
@Repository
public interface CartRepo {
	
	public Cart removeCart();
	public Cart addBookToCart();
	public Cart updateQuantity();
	
	

}
