package com.capgemini.Bookstore.Repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;

@Repository
public class BookRepoImpl implements BookRepo {

	@Override
	public List<Book> specificCategory() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> mostRecentPublishedBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> viewBestSellingBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> mostFavouredBook() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<BookReview> viewAllCustomerReview() {
		// TODO Auto-generated method stub
		return null;
	}

}
