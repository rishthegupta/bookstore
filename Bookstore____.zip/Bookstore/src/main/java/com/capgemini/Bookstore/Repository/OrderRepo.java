package com.capgemini.Bookstore.Repository;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Order;
@Repository
public interface OrderRepo {
	
	public Order viewAllDetailedOrder();
	

}
