package com.capgemini.Bookstore.bean;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;


@Entity
@Table(name = "bookdetail")
public class Book {

	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="book_ID",length=10)
	private int bookId;
	@NotNull
	@Column(name="book_title")
	private String bookTitle;
	@NotNull
	@Column(name="author")
	private String bookAuthor;
	@Column(name="discription")
	private String bookDesc;
	@NotNull
	@Column(name="ISBN_no")
	private String bookISBNo;
	@NotNull
	@Column(name="price")
	private float bookPrice;
	@NotNull
	@Column(name="publish_date")
	private Date bookPublishDate;
	@NotNull
	@Column(name="quantity")
	private int bookQuantity;

//	@Column(name="category")
	@OneToOne()
	private Category bookCategory;
	@NotNull
	@Column(name="image_link")
	private String bookImage;
//	@Column(name="bookreview")
	@OneToMany(cascade= CascadeType.ALL)
	private List<BookReview>  bookreview = new ArrayList<BookReview>();
	public Book(int bookId, String bookTitle, String bookAuthor, String bookDesc, String bookISBNo, float bookPrice,
			Date bookPublishDate, int bookQuantity, Category bookCategory, String bookImage,
			List<BookReview> bookreview) {
		super();
		this.bookId = bookId;
		this.bookTitle = bookTitle;
		this.bookAuthor = bookAuthor;
		this.bookDesc = bookDesc;
		this.bookISBNo = bookISBNo;
		this.bookPrice = bookPrice;
		this.bookPublishDate = bookPublishDate;
		this.bookQuantity = bookQuantity;
		this.bookCategory = bookCategory;
		this.bookImage = bookImage;
		this.bookreview = bookreview;
	}
	public Book() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookTitle() {
		return bookTitle;
	}
	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public String getBookDesc() {
		return bookDesc;
	}
	public void setBookDesc(String bookDesc) {
		this.bookDesc = bookDesc;
	}
	public String getBookISBNo() {
		return bookISBNo;
	}
	public void setBookISBNo(String bookISBNo) {
		this.bookISBNo = bookISBNo;
	}
	public float getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(float bookPrice) {
		this.bookPrice = bookPrice;
	}
	public Date getBookPublishDate() {
		return bookPublishDate;
	}
	public void setBookPublishDate(Date bookPublishDate) {
		this.bookPublishDate = bookPublishDate;
	}
	public int getBookQuantity() {
		return bookQuantity;
	}
	public void setBookQuantity(int bookQuantity) {
		this.bookQuantity = bookQuantity;
	}
	public Category getBookCategory() {
		return bookCategory;
	}
	public void setBookCategory(Category bookCategory) {
		this.bookCategory = bookCategory;
	}
	public String getBookImage() {
		return bookImage;
	}
	public void setBookImage(String bookImage) {
		this.bookImage = bookImage;
	}
	public List<BookReview> getBookreview() {
		return bookreview;
	}
	public void setBookreview(List<BookReview> bookreview) {
		this.bookreview = bookreview;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookTitle=" + bookTitle + ", bookAuthor=" + bookAuthor + ", bookDesc="
				+ bookDesc + ", bookISBNo=" + bookISBNo + ", bookPrice=" + bookPrice + ", bookPublishDate="
				+ bookPublishDate + ", bookQuantity=" + bookQuantity + ", bookCategory=" + bookCategory + ", bookImage="
				+ bookImage + ", bookreview=" + bookreview + "]";
	}
	
	
	
	
	
	
}
