package com.capgemini.Bookstore.Repository;

import org.springframework.stereotype.Repository;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Customer;

@Repository
public interface LoginRepo {
	
	public boolean addAdmin(Admin admin);
	public boolean addCustomer(Customer customer);
	public boolean loginAdmin(String adminEmailId,String password);
	public boolean loginCustomer(String customerEmail,String password);
}
