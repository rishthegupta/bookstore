package com.capgemini.Bookstore.Repository;

import java.util.List;

import com.capgemini.Bookstore.bean.Admin;
import com.capgemini.Bookstore.bean.Book;
import com.capgemini.Bookstore.bean.BookReview;
import com.capgemini.Bookstore.bean.Category;
import com.capgemini.Bookstore.bean.Customer;
import com.capgemini.Bookstore.bean.Order;

public interface AdminRepo {

	public List<Customer> viewAllCustomer();
	public Admin addAdmin();
	public Admin deleteAdmin(int id);
	public Admin updateAdmin(String adminEmailId, Admin admin);
	public List<Category> viewAllCategories();
	public Category createCategory( Category category);
	public Category deleteCategories(int categoryId);
	public Category updateCategories(int categoryId,Category category) ;
	public List<Book> viewAllBook();
	public Book deleteBook(int id);
	public Book addBook(Book book);
	public Book updateBook();
	public Customer createCustomer();
	public List<Customer> deleteCustomer();
	public Customer updateCustomer();
	public List<BookReview> viewAllReviews();
	public List<BookReview> deleteReview();
	public BookReview updateReview();
	public List<Order> viewAllOrders();
	public Order updateOrder();
	public Order deleteOrder();
	
	
}
