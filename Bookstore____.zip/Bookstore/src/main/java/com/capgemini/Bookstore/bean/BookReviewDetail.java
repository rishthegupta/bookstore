package com.capgemini.Bookstore.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "bookreviewdetail")
public class BookReviewDetail {
	
	@Id
	@NotNull
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="review_detail_ID")
	private int bookReviewDeatailID;
	@Column(name="headline")
	private String headline;
	@Column(name="discription")
	private String discription;
	@Column(name="rating")
	private int rating;
	public BookReviewDetail(int bookReviewDeatailID, String headline, String discription, int rating) {
		super();
		this.bookReviewDeatailID = bookReviewDeatailID;
		this.headline = headline;
		this.discription = discription;
		this.rating = rating;
	}
	public BookReviewDetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getBookReviewDeatailID() {
		return bookReviewDeatailID;
	}
	public void setBookReviewDeatailID(int bookReviewDeatailID) {
		this.bookReviewDeatailID = bookReviewDeatailID;
	}
	public String getHeadline() {
		return headline;
	}
	public void setHeadline(String headline) {
		this.headline = headline;
	}
	public String getDiscription() {
		return discription;
	}
	public void setDiscription(String discription) {
		this.discription = discription;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "BookReviewDetail [bookReviewDeatailID=" + bookReviewDeatailID + ", headline=" + headline
				+ ", discription=" + discription + ", rating=" + rating + "]";
	}
	
	

}
