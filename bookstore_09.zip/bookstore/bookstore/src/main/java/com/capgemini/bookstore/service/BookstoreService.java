package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.bean.Admin;
import com.capgemini.bookstore.bean.Book;
import com.capgemini.bookstore.bean.Category;
import com.capgemini.bookstore.bean.Customer;
import com.capgemini.bookstore.bean.Order;
import com.capgemini.bookstore.bean.OrderDetails;

public interface BookstoreService {
	
	//Customer Services
	public Customer addCustomer(Customer customer);
	public Customer editCustomer(Customer customer);
	public Customer removeCustomer(int customerID);
	public Customer findCustomer(int customerID);
	public List<Customer> findAllCustomer();
	
	//Books Services
	public Book addBook(Book book);
	public Book removeBook(int bookID);
	public List<Book> fetchAllBooks();
	
	//User Services
	
	public Admin removeUser(String emailID);
	public Admin addUser(Admin admin);
	public boolean authorizeUser(String emailID, String password);
	
	//Category Services
	
	public Category addCategory(Category category);
	public Category fetchOneCategory(int categoryID);
	public List<Category> fetchAllCategory();
	
	//Product Details Service
	
	public OrderDetails addProductDetails(OrderDetails details, int customerID);
	public OrderDetails fetchProductDerails(int orderDetailsID);
	
	//Cart Service
	
	public Order addProductToCart(Order order);
	public Order fetchCart(int cartID); 
	
	

}
