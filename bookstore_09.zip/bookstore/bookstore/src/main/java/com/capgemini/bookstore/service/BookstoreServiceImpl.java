package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.bean.Admin;
import com.capgemini.bookstore.bean.Book;
import com.capgemini.bookstore.bean.Category;
import com.capgemini.bookstore.bean.Customer;
import com.capgemini.bookstore.bean.Order;
import com.capgemini.bookstore.bean.OrderDetails;
import com.capgemini.bookstore.dao.BookstoreAdmin;
import com.capgemini.bookstore.dao.BookstoreBook;
import com.capgemini.bookstore.dao.BookstoreCategory;
import com.capgemini.bookstore.dao.BookstoreCustomer;
import com.capgemini.bookstore.dao.BookstoreOrder;
import com.capgemini.bookstore.dao.BookstoreOrderDetails;

@Service
public class BookstoreServiceImpl implements BookstoreService {
	
	
	@Autowired
	private BookstoreCustomer customerDAO;
	@Autowired
	private BookstoreBook bookDAO;
	@Autowired
	private BookstoreAdmin adminDAO;
	@Autowired
	private BookstoreCategory categoryDAO;
	@Autowired
	private BookstoreOrderDetails orderDetailsDAO;
	@Autowired
	private BookstoreOrder orderDAO;
	
	
	//Customer Services Implementation
	@Override
	public Customer addCustomer(Customer customer) {
		if(customer!=null)
		{
			customerDAO.save(customer);
			return customer;
		}
		return null;
	}

	@Override
	public Customer editCustomer(Customer customer) {
		if(customer!=null)
		{
			customerDAO.save(customer);
			return customer;
		}
		return null;
	}

	@Override
	public Customer removeCustomer(int customerID) {
		
		Customer customer=customerDAO.getOne(customerID);
		customerDAO.delete(customer);
		
		return customer;
	}

	@Override
	public Customer findCustomer(int customerID) {
		// TODO Auto-generated method stub
		return customerDAO.getOne(customerID);
	}

	@Override
	public List<Customer> findAllCustomer() {
		
		return customerDAO.findAll();
	}
	
	
	
	//Books Services Implementation
	
	@Override
	public Book addBook(Book book) {
		if(book!= null)
		{
			bookDAO.save(book);
			return book;
		}
		return null;
	}

	@Override
	public Book removeBook(int bookID) {
		
		if(bookID>0)
		{
			bookDAO.delete(bookDAO.getOne(bookID));
			return bookDAO.getOne(bookID);
		}
		
		return null;
	}

	@Override
	public List<Book> fetchAllBooks() {
		
		return bookDAO.findAll();
	}

	
	//Admin Service Implementation
	
	@Override
	public Admin removeUser(String emailID) {
		
		Admin admin=adminDAO.getOne(emailID);
		
		return admin;
	}

	@Override
	public Admin addUser(Admin admin) {
		if(admin!=null)
		{
			adminDAO.save(admin);
			return admin;
		}
		
		return null;
	}

	@Override
	public boolean authorizeUser(String emailID, String password) {
		
		Admin admin=adminDAO.getOne(emailID);
		
		if(admin.getAdminEmailId()==emailID && admin.getPassword()==password)
		{
			return true;
		}
		
		return false;
	}

	
	
	
	//Category Service Implementation
	
	
	@Override
	public Category addCategory(Category category) {
		if(category!=null)
		{
			categoryDAO.save(category);
			return category;
		}
		
		return null;
	}
	
	
	@Override
	public Category fetchOneCategory(int categoryID) {
		
		return categoryDAO.getOne(categoryID);
	}

	@Override
	public List<Category> fetchAllCategory() {
		
		return categoryDAO.findAll();
	}
	
	//ProductDetails Service Implementation

	@Override
	public OrderDetails addProductDetails(OrderDetails details, int customerID) {
		
		Order dummyOrder=new Order();
		
		if(details!=null )
		{
			orderDetailsDAO.save(details);
			dummyOrder.getOrdersDeails().add(details);
		
			customerDAO.getOne(customerID).getOrders().add(dummyOrder);
			
		}
		return details;
		
	}

	@Override
	public OrderDetails fetchProductDerails(int orderDetailsID) {
		
		return orderDetailsDAO.getOne(orderDetailsID);
	}
	
	
	//Cart Service Implementation

	@Override
	public Order addProductToCart(Order order) {
		if(order!=null)
		{
			orderDAO.save(order);
			return order;
			
		}
		
		return null;
	}

	@Override
	public Order fetchCart(int cartID) {
		
		return orderDAO.getOne(cartID);
	}

}
