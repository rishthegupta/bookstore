package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.bean.Category;

public interface BookstoreCategory extends JpaRepository<Category, Integer> {

}
