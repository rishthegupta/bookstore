package com.capgemini.Bookstore.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "cartdetail")
public class CartDetails {
	@Id
	private int  cartDetailID;
//	@Column(name="book_ID")
	@OneToOne
	private Book BookID;
	@ManyToOne(cascade= CascadeType.ALL)
	@JoinColumn(name="cart_ID")
	private Cart cartID;
	@Column(name="subtotal")
	private int subtotal;
	@Column(name="quantity")
	private int orderQuantity;
	public CartDetails(int cartDetailID, Book bookID, Cart cartID, int subtotal, int orderQuantity) {
		super();
		this.cartDetailID = cartDetailID;
		BookID = bookID;
		this.cartID = cartID;
		this.subtotal = subtotal;
		this.orderQuantity = orderQuantity;
	}
	public CartDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getCartDetailID() {
		return cartDetailID;
	}
	public void setCartDetailID(int cartDetailID) {
		this.cartDetailID = cartDetailID;
	}
	public Book getBookID() {
		return BookID;
	}
	public void setBookID(Book bookID) {
		BookID = bookID;
	}
	public Cart getCartID() {
		return cartID;
	}
	public void setCartID(Cart cartID) {
		this.cartID = cartID;
	}
	public int getSubtotal() {
		return subtotal;
	}
	public void setSubtotal(int subtotal) {
		this.subtotal = subtotal;
	}
	public int getOrderQuantity() {
		return orderQuantity;
	}
	public void setOrderQuantity(int orderQuantity) {
		this.orderQuantity = orderQuantity;
	}
	@Override
	public String toString() {
		return "CartDetails [cartDetailID=" + cartDetailID + ", BookID=" + BookID + ", cartID=" + cartID + ", subtotal="
				+ subtotal + ", orderQuantity=" + orderQuantity + "]";
	}
	
	

}
