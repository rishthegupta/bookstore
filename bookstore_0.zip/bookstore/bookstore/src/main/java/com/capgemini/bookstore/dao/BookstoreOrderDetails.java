package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.bean.OrderDetails;

public interface BookstoreOrderDetails extends JpaRepository<OrderDetails, Integer> {

}
