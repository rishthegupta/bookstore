package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.bean.Customer;

public interface BookstoreCustomer extends JpaRepository<Customer, Integer> {

}
