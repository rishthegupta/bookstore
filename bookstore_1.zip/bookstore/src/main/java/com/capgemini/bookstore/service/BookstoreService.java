package com.capgemini.bookstore.service;

import java.util.List;

import com.capgemini.bookstore.bean.Customer;

public interface BookstoreService {
	
	public Customer addCustomer(Customer customer);
	public Customer editCustomer(Customer customer);
	public Customer removeCustomer(int customerID);
	public Customer findCustomer(int customerID);
	public List<Customer> findAllCustomer();

}
