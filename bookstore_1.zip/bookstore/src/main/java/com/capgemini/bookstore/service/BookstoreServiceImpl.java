package com.capgemini.bookstore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bookstore.bean.Customer;
import com.capgemini.bookstore.dao.BookstoreCustomer;

@Service
public class BookstoreServiceImpl implements BookstoreService {
	
	
	@Autowired
	private BookstoreCustomer customerDAO;

	@Override
	public Customer addCustomer(Customer customer) {
		if(customer!=null)
		{
			customerDAO.save(customer);
			return customer;
		}
		return null;
	}

	@Override
	public Customer editCustomer(Customer customer) {
		if(customer!=null)
		{
			customerDAO.save(customer);
			return customer;
		}
		return null;
	}

	@Override
	public Customer removeCustomer(int customerID) {
		
		Customer customer=customerDAO.getOne(customerID);
		customerDAO.delete(customer);
		
		return customer;
	}

	@Override
	public Customer findCustomer(int customerID) {
		// TODO Auto-generated method stub
		return customerDAO.getOne(customerID);
	}

	@Override
	public List<Customer> findAllCustomer() {
		
		
		return customerDAO.findAll();
	}

}
