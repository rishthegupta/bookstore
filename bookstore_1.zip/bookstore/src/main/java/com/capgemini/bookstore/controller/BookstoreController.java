package com.capgemini.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.bookstore.bean.Customer;
import com.capgemini.bookstore.service.BookstoreServiceImpl;

@RestController
public class BookstoreController {
	
	
	@Autowired
	private BookstoreServiceImpl bookstoreService;
	
	@GetMapping(value="/")
	public String homePage()
	{
		return "BookStore HomePage";
	}
	
	
	//Fetch All Customers
	@GetMapping(value="/bookstore/fetchAllCustomer")
	public ResponseEntity<List<Customer>> fetchAllCustomer()
	{
		return ResponseEntity.accepted().body(bookstoreService.findAllCustomer());
	}
	
	//Fetch one customer, with customer id
	@GetMapping(value="/bookstore/fetchOneCustomer/{customerID}")
	public ResponseEntity<Customer> fetchOneCustomer(@PathVariable int customerID)
	{
		
		Customer customer=bookstoreService.findCustomer(customerID);
		return ResponseEntity.accepted().body(customer);
	}
	
	//Add new customer
	
	@PostMapping(value="/bookstore/addCustomer")
	public ResponseEntity<Customer> addCustomer(@RequestBody Customer customer)
	{
		return ResponseEntity.accepted().body(bookstoreService.addCustomer(customer));
	}
	
	

}
