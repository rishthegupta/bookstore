package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.bean.Book;

public interface BookstoreBook extends JpaRepository<Book, Integer> {

}
