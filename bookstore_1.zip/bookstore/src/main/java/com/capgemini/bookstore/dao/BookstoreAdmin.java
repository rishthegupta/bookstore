package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.bean.Admin;

public interface BookstoreAdmin extends JpaRepository<Admin, Integer> {

}
