import { Component, OnInit } from '@angular/core'
import { CustomerService } from './app.bookstoreService'

@Component({
    selector: 'show-app',
    templateUrl:'show.customer.html'

})

export class ShowCustomerComponent implements OnInit{



    constructor( private customerService:CustomerService){}


    allCustomers:any[];

    ngOnInit()

    {
        this.customerService.getAllCustomer().subscribe((data:any)=>this.allCustomers=data);
        this.customerService.getAllCustomer().subscribe((data:any)=>console.log(data));
    }


    deleteCustomer(customerID:any)
    {

        this.customerService.deleteCustomer(customerID);
    }

    

    
}