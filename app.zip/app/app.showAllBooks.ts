import { Component, OnInit } from '@angular/core'
import { CustomerService } from './app.bookstoreService'





@Component({
    selector:'all-books',
    templateUrl:'app.showAllBooks.html'
})
export class ShowAllBooks implements OnInit{
   
   
    constructor( private bookService:CustomerService){}
    

    allBooks:any[];

    ngOnInit()
    {
         this.bookService.getAllBooks().subscribe((data:any)=>this.allBooks=data)

    }


}