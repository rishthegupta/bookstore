

import { Component, OnInit } from '@angular/core'
import { CustomerService } from './app.bookstoreService'

import { Router } from '@angular/router'

@Component({
    selector:'add.app',
    templateUrl:'add.customer.html'
})


export class AddCustomerComponent{


    constructor(private customerService:CustomerService, private router:Router){}

    customer:any={}

    
    addCustomer():any{
       this.customerService.addCustomer(this.customer).subscribe();
       this.router.navigate(['/showCustomer']) 
    }




}