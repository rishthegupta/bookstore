﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule } from '@angular/forms'


import { ShowCustomerComponent } from './app.showCustomer'
import { AddCustomerComponent } from './app.addCustomer'
import { ShowAllBooks } from './app.showAllBooks'

import { Routes, RouterModule } from '@angular/router'


const router:Routes=[

    { path: 'addCustomer', component:AddCustomerComponent},
    { path: 'showCustomer', component:ShowCustomerComponent},
    { path: 'showAllBooks', component:ShowAllBooks},

]




@NgModule({
    imports: [
        BrowserModule, HttpClientModule, FormsModule, RouterModule.forRoot(router)
        
    ],
    declarations: [
        AppComponent, ShowCustomerComponent, AddCustomerComponent, ShowAllBooks
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }