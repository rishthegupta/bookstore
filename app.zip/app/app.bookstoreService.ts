import { Injectable } from '@angular/core'
import { HttpClient } from '@angular/common/http'



@Injectable({

    providedIn:'root'
})


export class CustomerService{


    constructor(private httpData:HttpClient){}

  

    getAllCustomer(){

        return this.httpData.get("http://localhost:8855/bookstore/fetchAllCustomer");
    }

    addCustomer(data:any){
        

        console.log(data.id);
        let input= new FormData();

        input.append("customerId",data.customerId);
        input.append("customerFullName", data.customerFullName);
        input.append("customerEmail", data.customerEmail);
        input.append("customerPhoneNumber", data.customerPhoneNumber);
        input.append("customerAddress", data.customerAddress);
        input.append("customerCity", data.customerCity);
        input.append("country", data.country);


        return this.httpData.post("http://localhost:8855/bookstore/addCustomer", input);

    }

 

    
    getAllBooks(){
        return this.httpData.get("http://localhost:8855/bookstore/fetchAllBook")

    }



    deleteCustomer(customerId:any)
    {
       
        this.httpData.delete("http://localhost:8855/bookstore/removeCustomer/"+customerId);
        console.log("reached "+ customerId);
    }

    

}

