package com.capgemini.bookstore.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.bookstore.bean.Order;

public interface BookstoreOrder extends JpaRepository<Order, Integer> {

}
